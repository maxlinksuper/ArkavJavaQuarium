public class Node <T> {
  public T data;
  public Node next;
}